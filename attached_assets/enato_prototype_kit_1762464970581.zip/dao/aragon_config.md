# Aragon DAO — Enato Demo (testnet)
Template: Multisig + Token voting (hybrid)
Roles:
- Elders multisig: 3 of 5
- Tribunal multisig: 2 of 3
- Citizens: ERC20 ENATO token (1:1 non-transferable recommended ⇒ use reputation plugin if available)

Process:
1) Create three multisig wallets.
2) Install TokenVoting. Set quorum 66%, support 50%.
3) Add Guard: proposals require tags `GLYPH:A-ELD`, `GLYPH:T-JUS`, and `GLYPH:P-COM` before executable (use off-chain preflight check or a bot).
4) Treasury: create sub‑vaults (Civilian, Military, Cosmic). Route payouts only after EXECUTE event emitted.
