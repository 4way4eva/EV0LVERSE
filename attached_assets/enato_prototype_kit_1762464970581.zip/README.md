# ENATO Codex Civilization — Prototype Starter Kit
Timestamp: 2025-10-17T06:16:55Z

This kit enables a no-code/low-code demo of Enato across three pillars:
1) Governance (agentic councils + ceremonial seals)
2) Treasury (π^4 compounding + distributions)
3) Quarter‑Lattice grid (cells, domes, and audit trails)

## Quick start
- Upload **prompts/enato_codex_system.txt** into a Custom GPT or any RAG chatbot builder.
- Use **flows/langflow_enato.json** in LangFlow to simulate council deliberations.
- Load **economy/treasury_sheet.csv** in Google Sheets and copy the formulas below.
- If you want a web demo, import **ui/bubble_schema.json** as your data schema guide.
- For a DAO testnet demo, follow **dao/aragon_config.md**.
- Use **stories/twine_outline.md** to author a policy scenario in Twine.
