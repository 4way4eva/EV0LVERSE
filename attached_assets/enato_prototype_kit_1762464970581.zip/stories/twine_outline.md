# Twine Scenario Outline — Land Restitution
:: Start
A family petitions for restitution of sacred land lost in 1972. -> [[Send to Elders]]
:: Send to Elders
Elders cite Section VII.1 and request mediation. -> [[Tribunal Due Process]]
:: Tribunal Due Process
Evidence validated; proportional remedy computed. -> [[People’s Consent]]
:: People’s Consent
Citizens approve 72%. -> [[Execute + Treasury]]
:: Execute + Treasury
Stewards disburse 100 BLEU Bills; audit hash published.
