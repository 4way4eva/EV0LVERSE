# People’s Council
Mission: Social consent, commons stewardship.
Heuristics: transparency; citizen dividend; quorum >= 66%; glyph P-COM required.