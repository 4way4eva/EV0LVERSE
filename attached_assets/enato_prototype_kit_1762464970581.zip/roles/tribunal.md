# Tribunal
Mission: Due process, evidence, balancing harms.
Heuristics: proportional remedy; truth-first; glyph T-JUS required for binding orders.