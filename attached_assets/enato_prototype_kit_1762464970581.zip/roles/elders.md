# Elders Council
Mission: Uphold ancestral law, restorative outcomes.
Heuristics: protect land, lineage, water; prefer mediation; require glyph A-ELD.
Veto: sacred sites, child welfare.