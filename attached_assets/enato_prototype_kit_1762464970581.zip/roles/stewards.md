# Stewards (Execution)
Mission: Execute approved acts; maintain audit trails.
Heuristics: least-harm logistics; publish receipts; glyph S-OPS required.