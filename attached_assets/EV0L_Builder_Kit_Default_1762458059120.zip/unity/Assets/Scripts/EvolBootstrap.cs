using UnityEngine;
using System.IO;
using System.Text;
public class EvolBootstrap : MonoBehaviour {
    void Start() {
        string cfgPath = Path.Combine(Application.streamingAssetsPath ?? "config", "vaults.json");
        if(File.Exists(cfgPath)) {
            string json = File.ReadAllText(cfgPath, Encoding.UTF8);
            Debug.Log("[EV0L] Loaded vaults.json: " + json.Substring(0, Mathf.Min(json.Length, 256)) + "...");
        } else {
            Debug.LogWarning("[EV0L] vaults.json not found at " + cfgPath);
        }
    }
}
