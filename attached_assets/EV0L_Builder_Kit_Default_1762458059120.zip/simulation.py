"""
EV0L yield simulator (pi^4 scaling).
Usage: python simulation.py <days> <initial_yield_usd>
"""
import sys, math, json
days = float(sys.argv[1]) if len(sys.argv)>1 else 1.0
y0 = float(sys.argv[2]) if len(sys.argv)>2 else 2.498e12  # total per day baseline
yt = y0 * (math.pi**4)**days
print(json.dumps({"days": days, "initial": y0, "pi4": math.pi**4, "yield": yt}, indent=2))
