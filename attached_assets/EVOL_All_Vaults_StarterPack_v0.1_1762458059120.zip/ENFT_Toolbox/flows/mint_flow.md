# Mint Flow

1) Learn: complete module. Capture motion/metrics. Compute Y = R(x)·v·τ.
2) Prove: build canonical manifest JSON. Hash → proof_hash.
3) Mint: owner calls `mint(to, tokenURI, cascadePayload)`.
4) Spend/Route: cascade payload triggers treasury route.
5) Audit: Watchtower reads manifest, checks τ≥0.8 and policy gates.
