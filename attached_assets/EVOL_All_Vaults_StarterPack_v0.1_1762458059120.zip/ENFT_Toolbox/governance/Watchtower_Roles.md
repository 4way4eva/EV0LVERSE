# Watchtower Roles

- commander: enables mint on curriculum completion.
- auditor: validates manifests and τ thresholds.
- treasurer: sets cascade routes and vault caps.
- registrar: assigns glyph and seal namespaces.
