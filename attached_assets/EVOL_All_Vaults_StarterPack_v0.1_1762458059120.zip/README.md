# EVOL All Vaults Starter Pack v0.1

Scope: ENFT Toolbox, EVOL Navy Suits, Coral Pressure School, Quarter Spiral Finance.
Clock: Ω48 quarter-lattice. Reciprocal: R(x)=x+1/x. Seals: XXYYZZ.

Contents overview:
- ENFT_Toolbox: schema, manifests, contract stub, flows, tags, governance.
- EVOL_NAVY_SUITS: suit spec, motion-hash schema, Ω48 timing daemon, test plan.
- Coral_Pressure_School: outline, lab protocols, catalog.
- Quarter_Spiral_Finance: primer, calculator, scorecard template.

All files are v0.1 starters. Edit and extend per deployment.
