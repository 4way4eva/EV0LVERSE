import math, argparse, json

def R(x: float) -> float:
    if x == 0:
        raise ValueError("x cannot be zero")
    return x + 1.0/x

def y_score(x: float, v: float, tau: float) -> float:
    return R(x) * v * tau

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--x", type=float, required=True)
    ap.add_argument("--v", type=float, required=True)
    ap.add_argument("--tau", type=float, required=True)
    args = ap.parse_args()
    out = {
        "R(x)": R(args.x),
        "pi4": math.pi**4,
        "Y": y_score(args.x, args.v, args.tau)
    }
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
