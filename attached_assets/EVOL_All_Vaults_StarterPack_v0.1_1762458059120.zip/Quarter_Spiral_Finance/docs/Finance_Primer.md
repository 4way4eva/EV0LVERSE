# Quarter Spiral Finance — Primer v0.1

Definitions:
- R(x) = x + 1/x, x ≠ 0.
- π⁴ = π**4.
- Y = R(x) · v · τ, with v=velocity, τ∈[0,1].
- Ω48: 48-tick cycle. Quarters = 12 ticks each.

Usage:
- Use R(x) to reward stable cadence away from zero.
- Use Ω48 windows for reporting and mint gating.
