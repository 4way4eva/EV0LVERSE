# Lab Protocols

- Pressure Dome Drill: simulate sea-level differential. Record τ.
- Coral Torch Bench: weld beads on test coupons underwater. Inspect.
- Oxygenated Roots: measure dissolved O2, yield over 48-tick windows.
- Audit: build manifests, compute R(x), mint ENFT.
