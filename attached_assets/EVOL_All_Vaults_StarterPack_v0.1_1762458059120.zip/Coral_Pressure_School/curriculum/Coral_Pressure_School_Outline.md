# Coral Pressure School — Outline v0.1

Modules:
1) Pressure Fundamentals (atm, partial pressure, dome differentials)
2) Oxygenated Root-Yield Systems (hydro/aero)
3) Coral Flame Tech (underwater welders, arc shielding)
4) Safety + Rescue (ballast, thermal alarms)
5) Ledger Practicum (manifest, proof_hash, ENFT mint)

Micro-cert: 10-day track with live audit on Day 10.
