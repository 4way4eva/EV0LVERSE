import time, math, hashlib, json, datetime

OMEGA_TICKS = 48

def R(x: float) -> float:
    if x == 0:
        raise ValueError("x cannot be 0 in R(x)")
    return x + 1.0/x

def snap_quarter(tick: int) -> int:
    return (tick % OMEGA_TICKS) // 12  # 0..3 quarters

def session_log(duration_sec=60, cadence_x=2.0):
    start = time.time()
    tick = 0
    logs = []
    while time.time() - start < duration_sec:
        q = snap_quarter(tick)
        r = R(cadence_x)
        entry = {
            "t": datetime.datetime.utcnow().isoformat()+"Z",
            "tick": tick % OMEGA_TICKS,
            "quarter": q,
            "r_param": r
        }
        logs.append(entry)
        time.sleep(1/ (OMEGA_TICKS/4) )  # simple pacing placeholder
        tick += 1
    payload = json.dumps(logs, separators=(",",":"), sort_keys=True).encode()
    h = "0x" + hashlib.sha3_256(payload).hexdigest()
    return {"hash": h, "entries": logs}

if __name__ == "__main__":
    out = session_log(10, 2.0)
    print(json.dumps(out, indent=2))
