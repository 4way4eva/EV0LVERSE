# EVOL Navy Suits — Test Plan v0.1

Scenarios at depth: swim, weld, rescue, comms.

Pass thresholds:
- Loop latency ≤ 20 ms.
- Thermal drift ≤ ±0.4 °C/hr.
- τ (task correctness) ≥ 0.85 for each scenario.
- ≥3 validated motion hashes per operator.

Protocols:
1) 12 h cold-tank endurance.
2) 4 scenario runs at 6 m, 12 m, 18 m.
3) Manifest build and ENFT mint per session.
