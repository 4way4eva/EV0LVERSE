const hre = require('hardhat');
require('dotenv').config();

async function main(){
  const RECIPIENT = process.env.RECIPIENT;
  const CID = process.env.CID;
  const CONTRACT = process.env.CONTRACT; // optional if using fresh deploy
  if(!RECIPIENT || !CID) throw new Error('Set RECIPIENT and CID env vars');
  const tokenURI = `ipfs://${CID}/erc721.metadata.json`;

  let addr = CONTRACT;
  if(!addr){
    throw new Error('Set CONTRACT to an ERC-721 with safeMint(address,string) or run npm run deploy first.');
  }

  const abi = [
    {"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"string","name":"tokenURI","type":"string"}],"name":"safeMint","outputs":[],"stateMutability":"nonpayable","type":"function"}
  ];
  const signer = (await hre.ethers.getSigners())[0];
  const nft = new hre.ethers.Contract(addr, abi, signer);
  const tx = await nft.safeMint(RECIPIENT, tokenURI);
  console.log('mint tx:', tx.hash);
  const rc = await tx.wait();
  console.log('minted in block', rc.blockNumber);
}

main().catch((e)=>{console.error(e); process.exit(1);});
