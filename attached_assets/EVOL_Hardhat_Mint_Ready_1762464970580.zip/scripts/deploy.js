const hre = require('hardhat');
async function main() {
  const Evol = await hre.ethers.getContractFactory('EvolWarCodex');
  const evol = await Evol.deploy();
  await evol.deployed();
  console.log('EvolWarCodex:', evol.address);
}
main().catch((e)=>{console.error(e); process.exit(1);});
