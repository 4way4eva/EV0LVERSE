require('dotenv').config();
require('@nomicfoundation/hardhat-toolbox');

const RPC_URL = process.env.RPC_URL || 'https://api.avax.network/ext/bc/C/rpc';
const PRIVATE_KEY = process.env.PRIVATE_KEY || '';

module.exports = {
  solidity: '0.8.20',
  networks: {
    avalanche: {
      url: RPC_URL,
      chainId: 43114,
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : []
    }
  }
};
