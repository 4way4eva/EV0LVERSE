# EVOL Hardhat Mint Ready

## Install
npm i

## Configure
cp .env.example .env
# edit RECIPIENT, CID, PRIVATE_KEY
# If deploying fresh, remove or clear CONTRACT then:
npm run deploy
# copy printed address into .env as CONTRACT

## Mint
npm run mint

## Notes
- TokenURI set to ipfs://<CID>/erc721.metadata.json from the EVOL_War_Codex_Mint_Package.
- Use verify_enft_hash.py to confirm artifact integrity.
