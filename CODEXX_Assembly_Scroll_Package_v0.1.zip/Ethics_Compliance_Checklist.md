# Ethics & Compliance Checklist (Biosecurity‑Aligned)

Scope
- Educational, ceremonial, and governance design only.
- No instructions for culturing cells, transferring nuclei, fusing cells, cryopreservation, or implantation.

Controls
- Strip stepwise methods, device settings, timings, and reagent mentions.
- Avoid personal health data in ENFT metadata.
- Require governance sign‑off before distribution.

Jurisdiction
- Confirm local and international law for any bio‑related work.
- Require IRB/IEC approvals for human/animal research contexts.
- Maintain audit trails via ENFT provenance and Watchtower logs.

Publication
- Use the tribunal‑safe edition for any public or investor distribution.
- Keep operational research, if any, in licensed facilities and never in public channels.
